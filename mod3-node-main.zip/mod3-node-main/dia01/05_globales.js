"use strict";
// Variables globales

// console.log("Hola");

// setInterval, clearInterval, setTimeout, clearTiemeout

// module, require

console.log(__filename);
console.log(__dirname);

console.log(process);
