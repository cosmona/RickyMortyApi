"use strict";

let a = 2;
let b = 3;

const result = Math.pow(a, b);

console.log("El resultado es:", result);
