const cowsay = require("cowsay");
//const chalk = require("chalk");
import chalk from "chalk";

console.log(chalk.blue("Hello world!"));

// console.log("Hola");

console.log(cowsay.say({ text: "Hola gente!!" }));

// console.log(chalk.blue("Hello world!"));
