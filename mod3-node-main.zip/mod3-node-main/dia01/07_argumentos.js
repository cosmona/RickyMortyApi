"use strict";
console.log("Argumentos del proceso:");
console.log(process.argv);
