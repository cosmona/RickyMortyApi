function getUser() {
  console.log("Function getUser");
}

module.exports = getUser;
