function deleteUser() {
  console.log("Function deleteUser");
}

module.exports = deleteUser;
