function createUser() {
  console.log("Function createUser");
}

module.exports = createUser;
