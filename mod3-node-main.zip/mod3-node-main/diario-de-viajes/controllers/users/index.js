const newUser = require('./newUser');

module.exports = { newUser };
