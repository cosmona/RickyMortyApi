const getEntry = require('./getEntry');
const listEntries = require('./listEntries');

module.exports = { getEntry, listEntries };
