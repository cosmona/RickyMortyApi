// ES module
import chalk from "chalk";

// añadir a package.json type:"module"

console.log(chalk.red("Hello world!"));
