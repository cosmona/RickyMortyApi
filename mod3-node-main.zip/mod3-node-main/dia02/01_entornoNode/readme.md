Node.js was written initially by Ryan Dahl in 2009
