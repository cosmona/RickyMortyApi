"use strict";
const { say } = require("cowsay");

//console.log(module);
// donde node busta los modulos
//console.log(module.paths);

console.log(say({ text: "Hola gente!!!!" }));
