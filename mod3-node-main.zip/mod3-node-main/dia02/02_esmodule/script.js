import { Fun1 as miFun } from "./script2.js";

const Fun1 = () => {
  console.log("Soy la Fun1 en script.js");
};

Fun1();
miFun();
