"use strict";

const Fun1 = () => {
  console.log("Function: Fun1");
};
