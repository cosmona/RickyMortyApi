"use strict";

const Fun1 = () => {
  console.log("Function: Fun2");
};

Fun1();
