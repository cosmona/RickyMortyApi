const miFun = () => {
  console.log("Hola desde aqui!");
};

// commonJS
module.exports = { miFun };
