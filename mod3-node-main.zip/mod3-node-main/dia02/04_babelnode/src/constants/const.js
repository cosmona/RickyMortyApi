// ES module
export const PI = 3.14;
